# Tuoni_Web_Attacking_Program
Tuoni - A web attacking program in development.

**Currently has the following capabilities:**
    
   * Shellshock attack
    
   * Directory fuzzer
   
   * Session hijacker
    
   * Get robots.txt file
   
   * Test file upload ability
   
   * Whois lookups
   
   * Zone transfers
   
   * Web spidering
   
   * Banner grabbing


**Currently working on adding:**
    
   * 

**Planning to work on:**
    
   * Password brute-forcer
   * SQL Injection
